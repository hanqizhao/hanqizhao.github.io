***********************************
Winamp5 Classified skin for Winamp
(Released January 17, 2004.)
***********************************

Now you'll be able to have the modern look
while using the low recources of a classic skin.

Original Design by Sven Kistner.
Classic Version by  Zarko Jovic and GuidoD.
Edited by Wildrose-Wally.

Copyright � 2004-2007 Sven Kistner, Zarko Jovic,
GuidoD & Wildrose-Wally. All rights reserved.